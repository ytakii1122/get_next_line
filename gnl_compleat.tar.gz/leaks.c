#include <libc.h>



__attribute__((destructor)) void destructor(void)

{

	int status;

	char buf[50];



	snprintf(buf, 50, "leaks %d &> leaksout", getpid());

	status = system(buf);

	if (status)

	{

		write(2, "leak!!!\n", 8);

		system("cat leaksout >/dev/stderr");

		exit(1);

	}

}
