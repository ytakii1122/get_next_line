# include"get_next_line.h"
# include"stdio.h"
//# include <stdlib.h>
//# include  <unistd.h>
//#define BUF_SIZE 100

int	main(void)
{
	char	*line;
	char	buf[BUFFER_SIZE + 1];
	int	fd;
	//int	ret;
	size_t	i;

	i = 0;
	fd = 0;
	//ret = 0;
	fd = open("sample.txt", O_RDONLY);
	if (fd < 0)
		return(-1);
	//line = get_next_line(fd);
	while (i < 15)
	{
		//ret = read(fd, buf, BUF_SIZE);
		line = get_next_line(fd);
		if (line < 0)
			return (-1);
		//line[ret] = '\0';
		printf("%s\n", line);
		i++;
	}
	//printf("%s\n", buf);
	//printf("%s\n", line);
	close(fd);
}
